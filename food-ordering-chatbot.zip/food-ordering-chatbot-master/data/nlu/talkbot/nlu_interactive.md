## intent:confirm.affirm
- yes
- yes
- yes
- yes
- yes
- yes
- yes

## intent:confirm.deny
- no
- nope
- no
- i changed my mind maybe later

## intent:cuisine.type
- i would like to have [mexican](cuisine)today
- would like to have some [italian](cuisine)
- would love to have [chinese](cuisine)
- lets have some [american](cuisine) dish
- let's try something [american](cuisine)

## intent:greetings.bye
- ok bye
- bye bye
- cool thanks
- okay thank you very much

## intent:greetings.hello
- hi
- hi
- hi
- hi
- hi

## intent:item.quantity
- [5](quant)
- [2](quant)
- 1 and 3
- 4[](quant:4)

## intent:selected.item
- let's have [burger](food)today
- would like to have some [biryani](food)
- [chole](food) [chawal](food)
- i want to have [noodles](food)
- [paratha](food)
- [idli](food) [sambar](food)
- p[aratha](food:paratha)
- b[urger](food:burger)

## synonym:burger
- urger
- Burger

## synonym:mexican
- Mexican

## synonym:paratha
- aratha
